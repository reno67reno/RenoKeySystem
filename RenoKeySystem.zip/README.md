
# Reno Key System

A Discord bot Lua key system for scripts.

## Commands

- `!createkey <key>` - Creates a key
- `!usekey <key>` - Activate a key
- `!checkkey <key>` - Check if key is used
